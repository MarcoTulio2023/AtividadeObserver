package com.finan.orcamento.Observer;

import static org.junit.jupiter.api.Assertions.*;

class EstoqueSubjectTest {

}