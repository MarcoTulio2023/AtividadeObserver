package com.finan.orcamento.Observer;

public interface GerenteObserverA {
    void update(EstoqueSubject subject);
}
