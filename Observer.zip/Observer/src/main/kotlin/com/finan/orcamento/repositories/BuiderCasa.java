package com.finan.orcamento.repositories;
import com.finan.orcamento.model.Casa;


public interface BuiderCasa {
}
